
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Miss Frederique Swaniawski II','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:38'),(2,'Ms. Ruth Medhurst','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:43'),(3,'Mr. Junius Boyer IV','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(4,'Mr. Randall Anderson MD','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(5,'Heath Greenholt','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:46'),(6,'Rozella Hane','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(7,'Mckayla Klocko','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:49'),(8,'Donavon Gaylord DDS','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(9,'Bethany Douglas','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:57'),(10,'Millie Treutel','formula',NULL,'2021-11-08 13:13:07','2021-11-08 13:14:01'),(11,'Sage O\'Reilly','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(12,'Garfield Jerde','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(13,'Lavinia Rosenbaum','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(14,'Nia Collier','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(15,'Amelie Schroeder','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(16,'Dr. Milton Abbott','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(17,'Brook Schaefer','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(18,'Enrique Corwin Jr.','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(19,'Kurtis Veum I','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(20,'Kendrick Botsford','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(21,'Dr. Coralie Kassulke PhD','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(22,'Rosina Tremblay','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(23,'Alberta Mann I','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(24,'Jeanie Streich','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(25,'Ms. Maud Gleason I','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(26,'Ray Smitham','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(27,'Cooper Cummings II','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(28,'Destinee Schumm','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(29,'Nichole Pagac','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(30,'Verner Cremin','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(31,'Mrs. Sabrina Turcotte V','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(32,'Richie Wuckert','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(33,'Jacey Murazik','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(34,'Benedict McDermott','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(35,'Deron Davis DDS','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(36,'Lori Predovic III','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(37,'Coleman Jaskolski III','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(38,'Kiana Rolfson','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(39,'Carolina Gottlieb','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(40,'Warren Christiansen','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(41,'Nick Bernhard','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(42,'Cortez Dach','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(43,'Ofelia Waelchi V','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(44,'Odie Harvey','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(45,'Jerrell Littel','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(46,'Mylene Yost','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(47,'Greyson Herzog V','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(48,'Jaycee Corkery DVM','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(49,'Mable Kihn','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(50,'Prof. Lexi Murazik DDS','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(51,'Ms. Guadalupe Russel DVM','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(52,'Mr. Maxwell D\'Amore III','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(53,'Elmo Towne','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(54,'Filomena Greenholt I','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(55,'Sophia Schowalter','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(56,'Darren Lueilwitz','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(57,'Rossie Runte II','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(58,'Barney Haag','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(59,'Prof. Raquel VonRueden','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(60,'Mr. Emiliano Reilly IV','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(61,'Jamey Conn','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(62,'Dejon Koelpin','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(63,'Seth Spencer II','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(64,'Karlie Torp','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(65,'Aubree Skiles','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(66,'Mr. Jaiden Stehr IV','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(67,'Ms. Thelma Goodwin Sr.','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(68,'Mohammed Wintheiser','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(69,'Emerson Daniel MD','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(70,'Prof. Curt Lindgren DDS','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(71,'Zane Abbott','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(72,'Brennan Johnston','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(73,'Jaida Torphy','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(74,'Dr. Rudy Baumbach I','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(75,'Jacinthe Lemke','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(76,'Bridie Fadel','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(77,'Raoul Fisher','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(78,'Ora Kohler','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(79,'Esperanza Deckow','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(80,'Celine Zboncak','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(81,'Devan Padberg PhD','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(82,'Golden Borer','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(83,'Freeda Jakubowski IV','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(84,'Deontae D\'Amore Jr.','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(85,'Eugene Littel','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(86,'Miss Elizabeth Hagenes Sr.','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(87,'Miss Della Towne Jr.','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(88,'Mrs. Katelynn Gutkowski','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(89,'Dr. Eldridge Harber','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(90,'Matteo Gusikowski','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(91,'Jean Breitenberg','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(92,'Prof. Selina Buckridge Sr.','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(93,'Morris Abernathy','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(94,'Otho Olson','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(95,'Miss Alize Lubowitz II','b',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(96,'Aryanna Bednar','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(97,'Dashawn Pfeffer','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(98,'Derick Jacobs','c',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(99,'Ramon Davis','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(100,'Dudley Roob','a',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `element_formula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `element_formula` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `formula_id` bigint(20) unsigned NOT NULL,
  `element_id` bigint(20) unsigned NOT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `element_formula` WRITE;
/*!40000 ALTER TABLE `element_formula` DISABLE KEYS */;
INSERT INTO `element_formula` VALUES (1,2,2,'20','2021-11-08 13:19:47','2021-11-08 13:19:47'),(2,2,4,'80','2021-11-08 13:19:47','2021-11-08 13:19:47'),(3,3,2,'20','2021-11-08 13:21:18','2021-11-08 13:21:18'),(4,3,4,'80','2021-11-08 13:21:18','2021-11-08 13:21:18'),(5,3,7,'52','2021-11-08 13:21:18','2021-11-08 13:21:18'),(6,3,51,'45','2021-11-08 13:21:18','2021-11-08 13:21:18');
/*!40000 ALTER TABLE `element_formula` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,'Paris Lebsack','a',31,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(2,'Elyssa Streich','a',7,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(3,'Stella Bailey III','c',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(4,'Orrin Crist','b',6,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(5,'Mozell Kunze','b',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(6,'Zena Cormier','a',49,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(7,'Maryam Deckow','c',15,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(8,'Karlie Stark','a',5,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(9,'Caroline Dietrich','c',39,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(10,'Marques Spencer','b',25,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(11,'Darion Bayer','b',1,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(12,'Giles Cummerata','c',38,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(13,'Miss Christy Ledner','c',46,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(14,'Isobel Rath','c',31,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(15,'Gwen Feeney','a',9,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(16,'Ms. Chyna Ziemann Sr.','a',25,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(17,'Adelia Towne DDS','a',4,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(18,'Alaina O\'Connell','a',8,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(19,'Dr. Xzavier Russel II','c',21,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(20,'Mustafa Marks I','b',18,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(21,'Elsa Wilkinson','a',43,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(22,'Nettie Grady','b',21,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(23,'Irving Bednar','b',34,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(24,'Maymie Heathcote','a',47,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(25,'Claudia Toy','a',22,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(26,'Eula Welch','c',10,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(27,'Ozella Langosh','a',45,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(28,'Taryn Grant','c',41,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(29,'Jamar Zboncak','a',48,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(30,'Oswald Christiansen','c',1,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(31,'Levi Gutkowski','a',16,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(32,'Olin Kerluke','a',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(33,'Brigitte Brakus','b',37,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(34,'Rosie Armstrong','b',41,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(35,'Terence Gleason','c',13,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(36,'Stone Windler','b',46,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(37,'Marisa Heidenreich','b',3,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(38,'Brent Bode','c',22,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(39,'Cheyanne Fritsch','a',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(40,'Jett Cronin','a',20,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(41,'Mrs. Kailey Volkman','b',37,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(42,'Juana Thiel','a',47,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(43,'Dimitri Collier','b',42,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(44,'Shawn Grady PhD','c',50,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(45,'Darrion Quitzon','b',23,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(46,'Aliya Legros','b',33,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(47,'Eldon Jacobs','b',34,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(48,'Amaya Koss','c',50,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(49,'Dedric Heathcote','c',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(50,'Margarita Farrell','b',5,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(51,'Ms. Bernice Bosco DVM','b',9,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(52,'Eunice Hauck','a',17,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(53,'Ashly Walsh','c',49,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(54,'Dr. Albert Barton','c',7,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(55,'Dr. Edythe Cummings','a',26,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(56,'Jared Conroy','c',3,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(57,'Brian Kozey','b',40,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(58,'Daniella Rutherford','b',1,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(59,'Prof. Jaren Hessel II','c',41,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(60,'Keyshawn Ferry','c',26,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(61,'Judah Feeney','b',25,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(62,'Mrs. Daniela Brekke I','a',39,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(63,'Dr. Dorris Keebler PhD','a',11,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(64,'Deborah Schuster','c',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(65,'Mack Morar','c',6,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(66,'Mr. Isidro Raynor II','a',2,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(67,'Dr. Patience Hilpert','a',2,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(68,'Emmie Yost','a',34,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(69,'Cordelia Smitham','a',6,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(70,'Dean Hyatt','c',24,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(71,'Alba Hansen','b',30,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(72,'Gerard Farrell','c',9,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(73,'Alessia Spencer','a',43,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(74,'Brent Keebler','a',45,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(75,'Hayden Hagenes','a',11,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(76,'Letha Waelchi','b',17,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(77,'Ms. Alexane Towne','a',1,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(78,'Miss Eloise McGlynn IV','a',44,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(79,'Darrin Abbott','b',14,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(80,'Wilfred Conn','c',1,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(81,'Bridgette Mertz','b',16,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(82,'Gina Harris','a',11,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(83,'Arvid Reinger I','b',7,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(84,'Renee Yost','b',20,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(85,'Prof. Cecil Hauck','c',15,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(86,'Randal Goyette','a',3,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(87,'Ruthie Frami','a',46,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(88,'Ms. Aracely Wisoky MD','a',18,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(89,'Bailee Bernier','b',20,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(90,'Simeon Lebsack','a',34,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(91,'Alexandre Dibbert','c',27,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(92,'Jazmin Paucek','a',17,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(93,'Antonina Wintheiser','b',11,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(94,'Mr. Tate Bogisich Sr.','c',17,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(95,'Dr. Jaime Harber I','c',25,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(96,'Dr. Amani Muller','c',36,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(97,'Treva Miller','a',45,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(98,'Everett Brown','a',1,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(99,'Shana Dietrich','c',27,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(100,'Mr. Emmet Stark','a',29,'2021-11-08 13:13:08','2021-11-08 13:13:08'),(101,'مدينة نصر ','b',3,'2021-11-09 06:35:46','2021-11-09 06:35:46');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `formulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formulas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `formulas` WRITE;
/*!40000 ALTER TABLE `formulas` DISABLE KEYS */;
INSERT INTO `formulas` VALUES (1,'formula 1','5231',5,'2021-11-08 13:15:40','2021-11-08 13:15:40'),(2,'Zane Thomas','Voluptatem Asperior',7,'2021-11-08 13:19:47','2021-11-08 13:19:47'),(3,'formula 2','st1123',7,'2021-11-08 13:21:18','2021-11-08 13:21:18');
/*!40000 ALTER TABLE `formulas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2021_10_30_183533_create_permission_tables',1),(6,'2021_10_30_190148_create_formulas_table',1),(7,'2021_10_30_190212_create_clients_table',1),(8,'2021_10_30_190236_create_categories_table',1),(9,'2021_10_30_190253_create_inventories_table',1),(10,'2021_10_30_190534_create_products_table',1),(11,'2021_10_30_191059_create_orders_table',1),(12,'2021_10_30_191952_create_elements_table',1),(13,'2021_10_31_222356_create_element_formula_table',1),(14,'2021_11_09_085558_create_activity_log_table',2),(15,'2021_11_09_085559_add_event_column_to_activity_log_table',2),(16,'2021_11_09_085600_add_batch_uuid_column_to_activity_log_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(1,'App\\Models\\User',6),(1,'App\\Models\\User',10),(1,'App\\Models\\User',11),(1,'App\\Models\\User',12),(1,'App\\Models\\User',17),(1,'App\\Models\\User',18),(1,'App\\Models\\User',19),(1,'App\\Models\\User',20),(1,'App\\Models\\User',21),(1,'App\\Models\\User',25),(1,'App\\Models\\User',32),(1,'App\\Models\\User',33),(1,'App\\Models\\User',35),(1,'App\\Models\\User',36),(1,'App\\Models\\User',39),(1,'App\\Models\\User',40),(1,'App\\Models\\User',41),(1,'App\\Models\\User',45),(1,'App\\Models\\User',46),(1,'App\\Models\\User',47),(1,'App\\Models\\User',49),(1,'App\\Models\\User',51),(1,'App\\Models\\User',54),(1,'App\\Models\\User',59),(1,'App\\Models\\User',63),(1,'App\\Models\\User',65),(1,'App\\Models\\User',66),(1,'App\\Models\\User',73),(1,'App\\Models\\User',79),(1,'App\\Models\\User',80),(1,'App\\Models\\User',84),(1,'App\\Models\\User',85),(1,'App\\Models\\User',89),(1,'App\\Models\\User',90),(1,'App\\Models\\User',96),(1,'App\\Models\\User',98),(2,'App\\Models\\User',2),(2,'App\\Models\\User',5),(2,'App\\Models\\User',7),(2,'App\\Models\\User',9),(2,'App\\Models\\User',14),(2,'App\\Models\\User',15),(2,'App\\Models\\User',16),(2,'App\\Models\\User',24),(2,'App\\Models\\User',38),(2,'App\\Models\\User',42),(2,'App\\Models\\User',52),(2,'App\\Models\\User',55),(2,'App\\Models\\User',58),(2,'App\\Models\\User',60),(2,'App\\Models\\User',61),(2,'App\\Models\\User',64),(2,'App\\Models\\User',67),(2,'App\\Models\\User',70),(2,'App\\Models\\User',74),(2,'App\\Models\\User',75),(2,'App\\Models\\User',76),(2,'App\\Models\\User',77),(2,'App\\Models\\User',78),(2,'App\\Models\\User',81),(2,'App\\Models\\User',86),(2,'App\\Models\\User',88),(2,'App\\Models\\User',92),(2,'App\\Models\\User',94),(2,'App\\Models\\User',95),(2,'App\\Models\\User',99),(3,'App\\Models\\User',3),(3,'App\\Models\\User',4),(3,'App\\Models\\User',8),(3,'App\\Models\\User',13),(3,'App\\Models\\User',22),(3,'App\\Models\\User',23),(3,'App\\Models\\User',26),(3,'App\\Models\\User',27),(3,'App\\Models\\User',28),(3,'App\\Models\\User',29),(3,'App\\Models\\User',30),(3,'App\\Models\\User',31),(3,'App\\Models\\User',34),(3,'App\\Models\\User',37),(3,'App\\Models\\User',43),(3,'App\\Models\\User',44),(3,'App\\Models\\User',48),(3,'App\\Models\\User',50),(3,'App\\Models\\User',53),(3,'App\\Models\\User',56),(3,'App\\Models\\User',57),(3,'App\\Models\\User',62),(3,'App\\Models\\User',68),(3,'App\\Models\\User',69),(3,'App\\Models\\User',71),(3,'App\\Models\\User',72),(3,'App\\Models\\User',82),(3,'App\\Models\\User',83),(3,'App\\Models\\User',87),(3,'App\\Models\\User',91),(3,'App\\Models\\User',93),(3,'App\\Models\\User',97),(3,'App\\Models\\User',100),(3,'App\\Models\\User',101),(3,'App\\Models\\User',102),(3,'App\\Models\\User',103);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'dashboard','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(2,'messages','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(3,'role-show','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(4,'role-edit','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(5,'role-create','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(6,'role-delete','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(7,'user-show','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(8,'user-edit','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(9,'user-create','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(10,'user-delete','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(11,'product-show','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(12,'product-edit','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(13,'product-create','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(14,'product-delete','web','2021-11-08 13:13:06','2021-11-08 13:13:06');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inventory_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(3,1),(5,2),(6,2),(7,1),(7,2),(9,2),(11,1),(11,2),(13,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'editor','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(2,'admin','web','2021-11-08 13:13:06','2021-11-08 13:13:06'),(3,'Feedback','web','2021-11-08 13:13:06','2021-11-08 13:13:06');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'editor','editor@taco.com','2021-11-08 13:13:07','$2y$10$ommNglxrbG5/5hxLHuW5bOYuJqFWQ4jMCKvjPa8dREUhYdrXDmO0e',1,'Yp5OztJzCW',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(2,'me4o','me4o@taco.com','2021-11-08 13:13:07','$2y$10$q27.cgM3aeZ/YbAa/iLUs.H3yA8CS95wpwGgGLLqjJI8YoNY2rz9O',1,'J2SvpibecY',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(3,'admin','admin@taco.com','2021-11-08 13:13:07','$2y$10$//OmoiqwWvNNLpFg2VzHBOCYgjWlU6rEEo0VhqimWAqQLJ6IE.iMi',1,'bLvlDCoh1z',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(4,'Nikolas Hickle','murazik.emelie@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'3f5YygGPxm',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(5,'Vergie Will','darryl.champlin@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'9gK5UbJRMz',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(6,'Constantin Paucek','concepcion58@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'aenEKVrtrH',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(7,'Prof. Deon Grimes','allen.torphy@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'x5mNQ4uyJp',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(8,'Edythe Abbott','ywiza@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'1wfpUjylp6',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(9,'Daniella Wunsch','grady.justina@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'rFOmugkcRm',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(10,'Orville Dickens','vanessa.russel@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Yh6lWQFUGx',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(11,'Lonnie Greenholt','xcollier@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'GYVL0AFenc',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(12,'Kayleigh Wehner','cgreenfelder@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Ulkcg4VAL9',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(13,'Damian Kutch','minerva74@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'XodwdaEonG',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(14,'Gunnar Blanda','gmcglynn@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'n7yYdAzdcP',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(15,'Dr. Nelson Block Sr.','luettgen.dino@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Y6cIgel3cR',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(16,'Dusty Stiedemann','keyon70@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'bbfLlva1ZH',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(17,'Anissa Brown','rylee62@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'HU7JVxFJTh',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(18,'Miss Vivian Miller III','raoul80@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'2FN8lg5aqb',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(19,'Germaine Kreiger','ryan.jarvis@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'fKlf5bo2nG',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(20,'Garrett Runolfsson','kenneth.breitenberg@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'oRyFFaHTIA',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(21,'Dr. Carmel Hessel III','uhammes@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'81BFXEyOpU',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(22,'Adelbert Schiller Sr.','laila.herzog@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'CA2xmxqdqz',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(23,'Elody Wolf','beer.jamarcus@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'uIVsXG3vMS',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(24,'Jeremy Cormier','jonas74@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'dLceFN9Y0Z',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(25,'Mr. Leonardo Hilpert II','westley.schiller@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'3wV9PN2KTD',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(26,'Darrion Block','wolf.lavern@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'dHmVoRRTdj',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(27,'Cathy Cummerata','jimmie94@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'qLy9EffidA',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(28,'Millie Schaefer DDS','hulda84@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'sTkklzZpTW',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(29,'Prof. Deangelo Gislason Sr.','clifford43@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'UAUzOdsxcJ',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(30,'Ed Runte','kailyn64@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'z32SH8piWM',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(31,'Salma Dach','lavinia77@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'rAw3o2Ptta',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(32,'Keshawn O\'Conner','mathew28@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'XQJmFJWO2y',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(33,'Marshall Purdy','zjast@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'F5bzZf59ld',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(34,'Prof. Selmer Keebler DDS','emil.doyle@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'VA44hqp73e',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(35,'Prof. Mckenna Gleason','desmond33@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'WAJzPqe5Vp',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(36,'Ruben Will','domenic.murphy@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'ExonFaAmqw',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(37,'Destini Mohr','mariana.spinka@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'rbQvipxlGo',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(38,'Christy Mayer PhD','kattie.green@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'R4Kkid28Jf',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(39,'Miss Amber Bernhard Jr.','connor.willms@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'sxPUGUDIJm',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(40,'Trent Sanford','wehner.tomasa@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'loVVsNLitL',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(41,'Maurice Rippin','taurean.zieme@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'0iWVJvq5uc',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(42,'Maymie Gislason','harber.shaina@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'JUCsAJTLaV',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(43,'Scarlett Fahey','kirstin05@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'C4IJErQv4Z',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(44,'Abbigail Huels','blittel@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Ha2fBCHryI',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(45,'Destin Purdy','magnus23@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'i3rnGhVWRN',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(46,'Vincent Reinger','yvette66@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'J9nlNgsTkO',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(47,'Johnny Hoeger','jokuneva@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'JBi3hDwlyB',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(48,'Vincenzo Metz','dante54@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'1ri7QKATYH',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(49,'Nadia Turner PhD','elroy.kessler@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'XZScOu7ur7',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(50,'Jenifer Hudson','nnikolaus@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Az4IswpPb8',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(51,'Arvilla Gaylord','darrel.mosciski@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'JvSiJiJGyB',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(52,'Kane Hane','sigrid08@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'CiybMNcxZh',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(53,'Adele Green','oma78@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Cb9VZ80yoh',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(54,'Prof. Juwan Sawayn V','okon.enoch@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'JhhcUQVrhM',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(55,'Romaine Prosacco DDS','augustine.vonrueden@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'10GKfhveCJ',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(56,'Seth Runolfsson','dheidenreich@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'NfFHIMLowi',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(57,'Winona Crist','vsteuber@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'B19JCQAOAt',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(58,'Katrine Gutkowski DDS','nella81@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'o51G4h7i3q',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(59,'Miss Kianna Sporer Jr.','abergnaum@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'UuGbmXo0Ga',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(60,'Ms. Martina Stamm DVM','runolfsson.orval@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'beQF12B5KS',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(61,'Ms. Eva Mraz I','ratke.berneice@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'pRtcJuSaek',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(62,'Scotty Torp','junior.quigley@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'9p8vPuP67O',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(63,'April Ankunding','henri25@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'i0UuWJ2xCi',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(64,'Lavada Beahan','kraig84@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'4kMOy3P5gM',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(65,'Prof. Sigmund Langosh DDS','monahan.daisha@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'6TicwppayJ',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(66,'Layla Hintz II','klein.filiberto@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'BByv3CLEJu',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(67,'Henry Rutherford','darrin42@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'LMUVUqKsjc',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(68,'Earline Lockman','hoeger.jairo@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'nZ859soD9O',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(69,'Miss Kenya Schuster','hnitzsche@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'J3JOk5BBKz',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(70,'Alexis Boehm PhD','ladarius.wilkinson@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'PW1MBUrOfG',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(71,'Prof. Alfonzo Grimes','clockman@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'HXmHBrNyOJ',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(72,'Angelica Heidenreich','lyda.bartell@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'QWcf2tBRCM',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(73,'May Oberbrunner','lemke.jose@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'thvt1lDCiG',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(74,'Brisa Stehr','alec.corkery@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'bhauKqx8Ep',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(75,'Gregoria Windler','delores.dickens@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'bqrg2MT2OC',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(76,'Bradley Schoen','gbechtelar@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'JDwrCIJWZX',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(77,'Winnifred Fahey PhD','dleannon@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'4zeKKmsrVC',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(78,'Darien Fahey','hansen.karelle@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'PxEc2xKY5A',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(79,'Miss Kaitlin Russel','kmcdermott@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'k5zmdEZL7J',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(80,'Mr. Fabian Murazik','carlo.ohara@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'jIZT9vKjqv',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(81,'Verlie Mueller','georgianna41@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'3HyMHNwNPW',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(82,'Miss Angeline Konopelski','jakayla02@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'J2CkrD15J6',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(83,'Florian Rodriguez','mreinger@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'zi5y9ct7Eo',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(84,'Dorris Bauch Sr.','hoppe.nyasia@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'dVqSBXIjr7',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(85,'Marcus Schmeler II','hand.cielo@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'laWvXP1yLe',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(86,'Alicia Prosacco','dwight.crooks@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'5iK6t6tym8',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(87,'Chaya Zemlak','uziemann@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'fd0nGsPUkx',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(88,'Evie Sipes','steuber.scot@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'LoijbmVvEq',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(89,'Cedrick Kub','bailee.wiegand@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'YXgj66mb9t',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(90,'Lemuel Maggio Sr.','benjamin01@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'nZehrTxJKl',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(91,'Jeramie Baumbach PhD','shanahan.roman@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'9AQtmu2EKW',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(92,'Don Ledner','eldred50@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'LVff3S962j',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(93,'Ollie Hamill Jr.','flo42@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'IiNhs8b9vY',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(94,'Jayda Lang','kessler.duncan@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'a6SKyocRDp',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(95,'Clovis Bradtke','bradtke.scotty@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'b57hGwJFUN',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(96,'Jammie Douglas','schmitt.dillon@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'M0ZtNrb0QV',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(97,'Gardner Cummings V','bmckenzie@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'jmwFMqMPnJ',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(98,'Dr. Zachery Gislason','yspencer@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'rRDuDEqNnW',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(99,'Colt Barton','chloe.robel@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'LJWxLoW8Du',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(100,'Lia Mayert','qkreiger@example.org','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'WQa2CMIEnz',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(101,'Rita Fisher','chadd23@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'VRGnfwWDJ5',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(102,'Enrico Hammes','kaltenwerth@example.com','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'Kmi53JXZ6e',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07'),(103,'Dawn Barrows','austen.corkery@example.net','2021-11-08 13:13:07','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,'IWKxLlPhuv',NULL,'2021-11-08 13:13:07','2021-11-08 13:13:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

